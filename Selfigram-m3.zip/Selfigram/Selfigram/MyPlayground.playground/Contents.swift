import UIKit

//Create
var arr:Array<Int>    = [1, 2, 3]
var dict:[String:Int] = ["one":1, "two":2, "three":3]
var s:Set             = [1, 2, 3]

//Append
arr.append(4)
arr += [5, 6, 7]
arr[0]

dict["four"] = 4
dict
dict["one"]

s.insert(4)

//Delete
arr.removeAtIndex(1)
arr

dict["two"] = nil
dict

s.remove(2)
s

//Update
arr[0] = 0
arr

dict["one"] = 0
dict

//Loops
//Array
var(str) = ""
for i in 0..<arr.count {
    str += "\(arr[i]), "
}
str

//2
str = ""
for var j = 0; j < arr.count; j++ {
    str += "\(arr[j]), "
}
str

//3
str = ""
for k in arr {
    str += "\(k), "
}
str

//4
str = ""
var l = 0
while l < arr.count {
    str += "\(arr[l]), "
    l++
}
str

//5
str = ""
var n = 0
repeat {
    str += "\(arr[n]), "
    n++
} while n < arr.count
str

//Dictionary
str = ""
for el in dict {
    str += el.0 + "\(el.1), "
}
str

//Set
str = ""
for el in s {
    str += "\(el), "
}
str








