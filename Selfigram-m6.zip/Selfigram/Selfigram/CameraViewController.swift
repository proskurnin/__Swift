//
//  CameraViewController.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 27.01.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class CameraViewController: UIViewController {

    @IBOutlet weak var activityGo: UIActivityIndicatorView!
    
    @IBAction func activityStartStop(sender: AnyObject) {
        if (activityGo.isAnimating() == true) {
            activityGo.stopAnimating()
        } else {
            activityGo.startAnimating()
        }
        
    }
    
}
