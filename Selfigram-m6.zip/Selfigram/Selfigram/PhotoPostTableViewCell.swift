//
//  PhotoPostTableViewCell.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 02.02.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class PhotoPostTableViewCell: UITableViewCell {

    @IBOutlet weak var userFullName: UILabel!
    @IBOutlet weak var descriptionPhoto: UILabel!
    @IBOutlet weak var timePost: UILabel!
    @IBOutlet weak var likeCount: UILabel!
    @IBOutlet weak var textComment: UILabel!

    @IBOutlet weak var likeNo: UIImageView!
    @IBOutlet weak var likeYes: UIImageView!
    
    
    
    @IBOutlet weak var likeButton: UIButton!
    
    
    @IBAction func likeButton(sender: AnyObject) {
        if likeYes.alpha == 0.0 {
           likeYes.alpha = 1.0
        } else {
           likeYes.alpha = 0.0
        }
        
        if likeNo.alpha == 1.0 {
            likeNo.alpha = 0.0
        } else {
            likeNo.alpha = 1.0
        }
        
        likeButton.alpha = 1.0
        
        delay(0.5) {
            self.likeButton.alpha = 0.8
        }
        delay(0.6) {
            self.likeButton.alpha = 0.6
        }
        delay(0.7) {
            self.likeButton.alpha = 0.4
        }
        delay(0.8) {
            self.likeButton.alpha = 0.2
        }
        delay(0.9) {
            self.likeButton.alpha = 0.1
        }
    }
    

    
    func delay(time: Double, closure: () -> () ) {
        dispatch_after(
            dispatch_time(DISPATCH_TIME_NOW, Int64(time * Double(NSEC_PER_SEC))),
            dispatch_get_main_queue(), closure)
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
