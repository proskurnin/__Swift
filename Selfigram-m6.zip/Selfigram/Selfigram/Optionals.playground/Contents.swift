class Test {
    var arr:[Int]? = [900, 600]
}

var num:Int! = 8 // unsafe
var str:String? = "Hello"
var test:Test? = Test()

// Optional unwrap
str!

// Optional chaining
test?.arr?[0]

// Optional binding
if let n = str {
    let str2 = n + " Word"
} else {
    print("ERROR")
}

