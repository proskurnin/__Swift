//
//  FeedViewController.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 27.01.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class FeedViewController: UIViewController {
    
    @IBOutlet weak var textFieldHello: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonShowText(sender: AnyObject) {
        textFieldHello.hidden = false
    }
    
}
