//
//  NetworkDataManagers.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 11.02.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import Foundation

class NetworkDataManagers:DataManager {
    
}
