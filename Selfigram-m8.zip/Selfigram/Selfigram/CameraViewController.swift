//
//  CameraViewController.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 27.01.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class CameraViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // UI
    @IBOutlet weak var imageView: UIImageView!
    
    var imagePicker:UIImagePickerController?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    // MARK: - Handlers
    
    @IBAction func takePhotoWasTapped(sender: AnyObject) {
        print("TAKE")
        imagePicker = UIImagePickerController()
        imagePicker!.delegate = self
        imagePicker!.sourceType = .Camera
        presentViewController(imagePicker!, animated: true) {}
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        imagePicker?.dismissViewControllerAnimated(true) {}
        imageView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
    }
    
    @IBAction func cameraSwitch(sender: AnyObject) {
        
    }
    
    @IBAction func cameraFlash(sender: AnyObject) {
    }
    
    
}
