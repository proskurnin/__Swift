//
//  DataManager.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 11.02.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import Foundation

// deprecated
/*protocol FeedDataManager {
    func getFeed()->AnyObject
}

protocol ProfileDataManager {
    func getProfile()->AnyObject
}*/

class DataManager {
    
    // Sinletone
    static let sharedInstance = DataManager()
    private init() {
    }
    
    // MARK: API
    
    func getFeed()->AnyObject {
        return ["a", "b"]
    }

    func getProfile()->AnyObject {
        return [0, 1]
    }
    
    private func loadProfile()->AnyObject {
        return [0, 1]
    }
    
}
