//
//  PhotoData.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 02.02.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import Foundation

class PhotoData {
    
    var userId:Int
    var photoUrl:String
    
    init(userId:Int, photoUrl:String) {
        self.userId = userId
        self.photoUrl = photoUrl
    }
    
}