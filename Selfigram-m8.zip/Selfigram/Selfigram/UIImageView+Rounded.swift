//
//  UIImageView+Rounded.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 05.02.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

extension UIImageView {
    
    func maskAsRounded() {
        layer.cornerRadius = frame.width / 2
        layer.masksToBounds = true
    }
}
