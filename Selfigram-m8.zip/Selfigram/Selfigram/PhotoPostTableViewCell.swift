//
//  PhotoPostTableViewCell.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 02.02.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class PhotoPostTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var likeOverlayImageView: UIImageView!
    @IBOutlet weak var photoImageView: UIImageView!
    
    @IBOutlet weak var userFullName: UILabel!
    @IBOutlet weak var descriptionPhoto: UILabel!
    @IBOutlet weak var timePost: UILabel!
    @IBOutlet weak var likeCount: UILabel!

    @IBOutlet weak var likeNo: UIImageView!
    @IBOutlet weak var likeYes: UIImageView!
    
    @IBOutlet weak var textComment: UILabel!
    @IBOutlet weak var commentField: UITextField!
    
    var arrComment:Array<String> = []
    var str:String = ""
    
    func delay(time: Double, closure: () -> () ) {
        dispatch_after(
            dispatch_time(DISPATCH_TIME_NOW, Int64(time * Double(NSEC_PER_SEC))),
            dispatch_get_main_queue(), closure)
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        // avatar
        avatarImageView.maskAsRounded()
        
        // tap
        likeOverlayImageView.hidden = true
        
        let tap = UITapGestureRecognizer(target: self, action: "photoWasTapped")
        photoImageView.addGestureRecognizer(tap)
        
       
        
    }

    
    func photoWasTapped () {
        likeOverlayImageView.hidden = false
        
        // animation
        UIView.animateWithDuration(1, animations: {
            self.likeOverlayImageView.alpha = 0
            }) { finished in
        }
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func sendComment(sender: AnyObject) {
        
        // comments
        str = ""
        arrComment.append(commentField.text!)
        for k in arrComment {
            str += "\(k), "
        }
        textComment.text = str
    }

}
