//
//  ProfileViewController.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 27.01.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var testSwith: UISwitch!
    @IBOutlet weak var labelArray: UILabel!
    @IBOutlet weak var labelDict: UILabel!
    @IBOutlet weak var labelSet: UILabel!
    @IBOutlet weak var labelOut: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(DataManager.sharedInstance.getProfile())
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func forTestSwitch(){
        switch testSwith.on {
        case true:
            testSwith.setOn(false, animated: true)
        case false:
            testSwith.setOn(true, animated: true)
        }
    }
    
    func forArrayButton() {
        var arr:Array<Int> = []
        for var j = 0; j < 10; j++ {
            arr.append(Int(arc4random_uniform(UInt32((9 - 1) + 1))) + 1)
        }
        
        var(strOut) = ""
        for i in 0..<arr.count {
            strOut += "\(arr[i]), "
        }
        labelOut.text = strOut
        
        var sumArray = 0
        for var j = 0; j < 10; j++ {
            sumArray = sumArray + arr[j]
        }
        let strArray = String(sumArray)
        labelArray.text = strArray
    }
    
    func forDictButton() {
        let dict:[Int:String] = [1:"Veronika", 2:"Artur", 3:"Valeriya"]
        var strDict = ""
        for el in dict {
            strDict += el.1
        }
        
        var(strOut) = ""
        for el in dict {
            strOut += "\(el.0):" + el.1 + ", "
        }
        labelOut.text = strOut
        
        let cntDict = strDict.characters.count
        let strDictLabl = String(cntDict)
        labelDict.text = strDictLabl
    }
    
    func forSetButton() {
        var setMy:Set = [1]
        for var k = 0; k < (Int(arc4random_uniform(UInt32((99 - 10) + 10))) + 10); k++ {
            setMy.insert(Int(arc4random_uniform(UInt32((9 - 1) + 1))) + 1)
        }
        
        var(strOut) = ""
        for el in setMy {
            strOut += "\(el), "
        }
        labelOut.text = strOut
        
        let cntSet = setMy.count
        let strSetLabl = String(cntSet)
        labelSet.text = strSetLabl
    }
    
    @IBAction func testButtonTaped(sender: AnyObject) {
        
        forTestSwitch()
        
        //print(testSwith.on)
        //testSwith.on = !testSwith.on
        
        /* if (testSwith.on == true) {
        testSwith.setOn(false, animated: true)
        } else {
        testSwith.setOn(true, animated: true)
        } */
        
    }
    
    @IBAction func buttonArray(sender: AnyObject) {
        forArrayButton()
    }

    @IBAction func buttonDict(sender: AnyObject) {
        forDictButton()
    }
    
    @IBAction func buttonSet(sender: AnyObject) {
        forSetButton()
    }

}
