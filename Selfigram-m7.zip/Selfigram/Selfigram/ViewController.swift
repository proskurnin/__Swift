//
//  ViewController.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 26.01.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class ViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let font = UIFont(name: "HelveticaNeue", size: 10)
        UITabBar.appearance().tintColor = UIColor.whiteColor()
        
        
        let pvc1 = viewControllers![0]
        pvc1.tabBarItem.image = UIImage(named: "tab_feed_icon")!.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        pvc1.tabBarItem.setTitleTextAttributes([NSFontAttributeName: font!, NSForegroundColorAttributeName: UIColor.whiteColor()], forState: UIControlState.Normal)
        pvc1.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: -29, bottom: -6, right: 29)
        
        let pvc2 = viewControllers![1]
        pvc2.tabBarItem.image = UIImage(named: "tab_camera_icon")!.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        pvc2.tabBarItem.setTitleTextAttributes([NSFontAttributeName: font!, NSForegroundColorAttributeName: UIColor.whiteColor()], forState: UIControlState.Normal)
        pvc2.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: -33, bottom: -6, right: 33)
        
        let pvc3 = viewControllers![2]
        pvc3.tabBarItem.image = UIImage(named: "tab_profile_icon")!.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        pvc3.tabBarItem.setTitleTextAttributes([NSFontAttributeName: font!, NSForegroundColorAttributeName: UIColor.whiteColor()], forState: UIControlState.Normal)
        pvc3.tabBarItem.imageInsets = UIEdgeInsets(top: 6, left: -34, bottom: -6, right: 34)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

