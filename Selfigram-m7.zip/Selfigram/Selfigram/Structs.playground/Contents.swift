import Foundation

//Classes

class Fruit:NSObject {
    var weigth:Int = 500
}

var fruit = Fruit()
var fruit2 = fruit

fruit2.weigth = 100
fruit.weigth

var isFruitsEqual:Bool = fruit == fruit2
isFruitsEqual

// Structs

struct Vegetable:CustomStringConvertible {
    var weight:Int
    var date:String
    
    var description:String {
        return "<Vegetable weight = \(weight)>"
    }
}

var veg = Vegetable(weight: 900, date: "2015")
var veg2 = veg

veg2.weight = 2000
veg.weight