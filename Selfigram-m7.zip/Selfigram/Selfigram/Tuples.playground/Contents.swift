// return type
func getLikes() -> (likes:Int, name:String) {
    return (30, "Masha")
}

getLikes().likes

func getLikes2() -> (likes:Int, name:String)? {
    return nil
}

getLikes2()?.name

// Tuple in Dictionary
var dict = ["Masha": 30, "Olya": 100]

var s = ""
for i in dict {
    s += i.0 + ", "
}
s

// var
let names = ("Masha", "Olya", "Natasha")

