// Simple

enum Fruit {
    case Apple
    case Pear
    case Orange
}

let f:Fruit = .Apple


// Complex 1

enum Trafficlight {
    case Red
    case Yellow
    case Green
    
    mutating func nextLight() {
        switch self {
        case .Red:
            self = Yellow
        case .Yellow:
            self = Green
        case .Green:
            self = Red
        }
    }
}

var tf:Trafficlight = Trafficlight.Red
tf
tf.nextLight()
tf.nextLight()
tf.nextLight()

// Complex 2

enum Car:String {
    case Toyota = "Japan"
    case Lada = "Russia"
    case BMW = "Germany"
}

let c = Car.BMW
c.rawValue

enum CustomCar {
    case NonameFromChina(name:String)
    case NonameFromSomewhere(name:String)
}


var cc = CustomCar.NonameFromChina(name: "GreatWall")
cc
cc = CustomCar.NonameFromSomewhere(name: "UFO")
cc
