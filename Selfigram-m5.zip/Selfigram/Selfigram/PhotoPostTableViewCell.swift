//
//  PhotoPostTableViewCell.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 02.02.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class PhotoPostTableViewCell: UITableViewCell {

    @IBOutlet weak var userFullName: UILabel!
    @IBOutlet weak var descriptionPhoto: UILabel!
    @IBOutlet weak var timePost: UILabel!
    @IBOutlet weak var likeCount: UILabel!
    @IBOutlet weak var textComment: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
