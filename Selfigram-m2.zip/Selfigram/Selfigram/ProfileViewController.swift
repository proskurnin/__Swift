//
//  ProfileViewController.swift
//  Selfigram
//
//  Created by Roman Proskurnin on 27.01.16.
//  Copyright © 2016 Roman Proskurnin. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var testSwith: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func testButtonTaped(sender: AnyObject) {
        //print(testSwith.on)
        //testSwith.on = !testSwith.on
        
        /* if (testSwith.on == true) {
            testSwith.setOn(false, animated: true)
        } else {
            testSwith.setOn(true, animated: true)
        } */
        
        switch testSwith.on {
        case true:
            testSwith.setOn(false, animated: true)
        case false:
            testSwith.setOn(true, animated: true)
        }
    }
    
    
}
